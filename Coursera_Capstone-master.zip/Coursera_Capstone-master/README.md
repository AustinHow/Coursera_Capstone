# Coursera Capstone repository

This repo was created as part of the Coursera [Applied Data Science Capstone](https://www.coursera.org/learn/applied-data-science-capstone) course.

Final project submissions:

* Notebook with code [Assignment Week 5 - final notebook.ipynb](https://github.com/mandieq/Coursera_Capstone/blob/master/Assignment%20Week%205%20-%20final%20notebook.ipynb)
* Final report (PDF) [Capstone Project Report MQ.pdf](https://github.com/mandieq/Coursera_Capstone/blob/master/Capstone%20Project%20Report%20MQ.pdf)
* Blog post [Exploring WeWork locations in London](https://medium.com/@mandieq/exploring-wework-locations-in-london-88e01e37f8e) 
